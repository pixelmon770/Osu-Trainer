// Historia analiz w lokalnej bazie SQLite (plik osu-trainer.sqlite w folderze danych programu).
// sql.js to SQLite skompilowany do WebAssembly – nie wymaga kompilowania niczego na Windows.

import { readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { gunzipSync, gzipSync } from 'node:zlib';
import type { ReplayAnalysis } from '@osu-trainer/analyzer';
import { app } from 'electron';
import initSqlJs, { type Database } from 'sql.js';
import type { DrillRecord, MapGroup, MapInfo, ReplayFilter, ReplayResult, ReplaySource, ReplaySummary } from '../shared/api.ts';

const SCHEMA_VERSION = 7;
const dbFile = () => join(app.getPath('userData'), 'osu-trainer.sqlite');

let dbPromise: Promise<Database> | null = null;
let saveTimer: NodeJS.Timeout | null = null;

function open(): Promise<Database> {
  dbPromise ??= (async () => {
    const SQL = await initSqlJs();
    let db: Database;
    try {
      db = new SQL.Database(new Uint8Array(await readFile(dbFile())));
    } catch {
      db = new SQL.Database();
    }
    migrate(db);
    return db;
  })();
  return dbPromise;
}

function migrate(db: Database): void {
  const version = (db.exec('PRAGMA user_version')[0]?.values[0]?.[0] as number) ?? 0;
  if (version < 1) {
    db.run(`
      CREATE TABLE IF NOT EXISTS replays (
        id TEXT PRIMARY KEY,
        file TEXT NOT NULL,
        map_file TEXT NOT NULL,
        beatmap_md5 TEXT NOT NULL,
        artist TEXT, title TEXT, version TEXT, creator TEXT, map_end_ms INTEGER,
        played_at TEXT NOT NULL,
        analyzed_at TEXT NOT NULL,
        mods TEXT NOT NULL,
        score INTEGER, max_combo INTEGER, accuracy REAL,
        count300 INTEGER, count100 INTEGER, count50 INTEGER, count_miss INTEGER,
        ur REAL, mean_error REAL, k1_mean REAL, k2_mean REAL, k1_ur REAL, k2_ur REAL,
        stream_ur REAL, outside_ur REAL, entry_mean REAL, alternation REAL, tap_spread REAL,
        partial INTEGER NOT NULL,
        analysis BLOB NOT NULL
      );
      CREATE INDEX IF NOT EXISTS replays_played_at ON replays(played_at DESC);
      CREATE INDEX IF NOT EXISTS replays_beatmap ON replays(beatmap_md5);
      CREATE INDEX IF NOT EXISTS replays_file ON replays(file);
    `);
  }
  if (version < 2) {
    db.run(`ALTER TABLE replays ADD COLUMN source TEXT NOT NULL DEFAULT 'stable'`);
  }
  if (version < 3) {
    // ta sama gra zapisana pod różnymi plikami (np. lazer zapisał replay ponownie) – zostawiamy pierwszy wpis
    db.run(`DELETE FROM replays WHERE rowid NOT IN (
      SELECT MIN(rowid) FROM replays GROUP BY beatmap_md5, played_at, score
    )`);
    db.run('CREATE INDEX IF NOT EXISTS replays_play ON replays(beatmap_md5, played_at, score)');
  }
  if (version < 4) {
    // BPM streamów mapy (NULL = jeszcze nie policzone, 0 = mapa bez streamów, -1 = brak pliku mapy)
    db.run('ALTER TABLE replays ADD COLUMN stream_bpm REAL');
  }
  if (version < 5) {
    db.run(`
      CREATE TABLE IF NOT EXISTS drills (
        id TEXT PRIMARY KEY,
        created_at TEXT NOT NULL,
        kind TEXT NOT NULL,
        name TEXT NOT NULL,
        label TEXT NOT NULL,
        bpm REAL, duration_ms INTEGER, notes INTEGER, accuracy REAL, misses INTEGER, extra_taps INTEGER,
        wrong_finger INTEGER, ur REAL, mean REAL, k1_mean REAL, k2_mean REAL, k1_ur REAL, k2_ur REAL,
        entry_mean REAL, tap_spread REAL
      );
      CREATE INDEX IF NOT EXISTS drills_kind_name ON drills(kind, name, created_at DESC);
    `);
  }
  if (version < 6) {
    db.run('ALTER TABLE drills ADD COLUMN aim_distance REAL');
    db.run('ALTER TABLE drills ADD COLUMN aim_overshoot REAL');
    db.run('ALTER TABLE drills ADD COLUMN hit_rate REAL');
  }
  if (version < 7) {
    // Biblioteka map: wynik analizy każdej lokalnej mapy (liczony raz, potem tylko nowe mapy)
    db.run(`
      CREATE TABLE IF NOT EXISTS maps (
        md5 TEXT PRIMARY KEY,
        path TEXT NOT NULL,
        source TEXT NOT NULL,
        algo INTEGER NOT NULL,
        title TEXT, artist TEXT, version TEXT, creator TEXT,
        beatmap_id INTEGER, set_id INTEGER,
        stars REAL, bpm REAL, length_ms INTEGER,
        ar REAL, od REAL, cs REAL, objects INTEGER,
        stream_bpm REAL, stream_pct REAL, longest_stream INTEGER, longest_block_ms INTEGER, stream_spacing REAL,
        jumps_per_min REAL, jump_distance REAL, overlap_pct REAL,
        error TEXT,
        indexed_at TEXT NOT NULL
      )`);
  }
  db.run(`PRAGMA user_version = ${SCHEMA_VERSION}`);
}

/** Zapis na dysk z opóźnieniem – kilka analiz pod rząd = jeden zapis. */
function scheduleSave(db: Database): void {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => void flush(db), 800);
}

async function flush(db: Database): Promise<void> {
  saveTimer = null;
  const data = db.export();
  const tmp = dbFile() + '.tmp';
  try {
    await writeFile(tmp, data);
    await rename(tmp, dbFile()); // podmiana całego pliku naraz – brak uszkodzeń przy zamknięciu w trakcie
  } catch {
    // Windows potrafi zablokować podmianę (antywirus, indeksowanie) – wtedy zapis wprost
    await writeFile(dbFile(), data).catch((e) => console.error('Nie udało się zapisać historii:', e));
  }
}

/** Czy jest zapis czekający na dysk. */
export function hasPendingSave(): boolean {
  return saveTimer !== null;
}

export async function flushNow(): Promise<void> {
  if (!dbPromise || !saveTimer) return;
  clearTimeout(saveTimer);
  await flush(await dbPromise);
}

export async function saveReplay(r: {
  id: string;
  replayFile: string;
  mapFile: string;
  beatmapMd5: string;
  map: MapInfo;
  analysis: ReplayAnalysis;
  source: ReplaySource;
  streamBpm: number;
}): Promise<ReplaySummary> {
  const db = await open();
  const a = r.analysis;
  db.run(
    `INSERT OR REPLACE INTO replays (
      id, file, map_file, beatmap_md5, artist, title, version, creator, map_end_ms,
      played_at, analyzed_at, mods, score, max_combo, accuracy,
      count300, count100, count50, count_miss, ur, mean_error, k1_mean, k2_mean, k1_ur, k2_ur,
      stream_ur, outside_ur, entry_mean, alternation, tap_spread, partial, analysis, source, stream_bpm
    ) VALUES (
      $id, $file, $map_file, $beatmap_md5, $artist, $title, $version, $creator, $map_end_ms,
      $played_at, $analyzed_at, $mods, $score, $max_combo, $accuracy,
      $c300, $c100, $c50, $miss, $ur, $mean, $k1, $k2, $k1ur, $k2ur,
      $stream_ur, $outside_ur, $entry, $alt, $spread, $partial, $analysis, $source, $stream_bpm)`,
    {
      $id: r.id,
      $file: r.replayFile,
      $map_file: r.mapFile,
      $beatmap_md5: r.beatmapMd5,
      $artist: r.map.artist,
      $title: r.map.title,
      $version: r.map.version,
      $creator: r.map.creator,
      $map_end_ms: r.map.endMs,
      $played_at: a.playedAt,
      $analyzed_at: new Date().toISOString(),
      $mods: a.mods.join(','),
      $score: a.score,
      $max_combo: a.maxCombo,
      $accuracy: a.header.accuracy,
      $c300: a.header.count300,
      $c100: a.header.count100,
      $c50: a.header.count50,
      $miss: a.header.countMiss,
      $ur: a.errors.ur,
      $mean: a.errors.mean,
      $k1: a.keys.K1.mean,
      $k2: a.keys.K2.mean,
      $k1ur: a.keys.K1.ur,
      $k2ur: a.keys.K2.ur,
      $stream_ur: a.streams.errors.ur,
      $outside_ur: a.streams.outside.ur,
      $entry: a.streams.entry.mean,
      $alt: a.streams.alternation,
      $spread: a.streams.tapSpread,
      $partial: a.partial ? 1 : 0,
      $analysis: gzipSync(JSON.stringify(a)),
      $source: r.source,
      $stream_bpm: r.streamBpm
    }
  );
  scheduleSave(db);
  return (await getSummary(r.id))!;
}

const SUMMARY_COLUMNS = `id, file, beatmap_md5, artist, title, version, played_at, analyzed_at, mods, accuracy, count_miss,
  max_combo, ur, k1_mean, k2_mean, stream_ur, entry_mean, alternation, tap_spread, partial, source, stream_bpm`;

function toSummary(row: Record<string, unknown>): ReplaySummary {
  return {
    id: row.id as string,
    file: row.file as string,
    beatmapMd5: (row.beatmap_md5 as string) ?? '',
    artist: (row.artist as string) ?? '',
    title: (row.title as string) ?? '',
    version: (row.version as string) ?? '',
    playedAt: row.played_at as string,
    analyzedAt: row.analyzed_at as string,
    mods: ((row.mods as string) || '').split(',').filter(Boolean),
    accuracy: row.accuracy as number,
    countMiss: row.count_miss as number,
    maxCombo: row.max_combo as number,
    ur: row.ur as number,
    k1Mean: row.k1_mean as number,
    k2Mean: row.k2_mean as number,
    streamUr: row.stream_ur as number,
    entryMean: (row.entry_mean as number) ?? 0,
    alternation: (row.alternation as number) ?? 0,
    tapSpread: (row.tap_spread as number) ?? 0,
    partial: row.partial === 1,
    source: ((row.source as string) || 'stable') as ReplaySource,
    streamBpm: (row.stream_bpm as number | null) ?? null
  };
}

function rows(db: Database, sql: string, params: Record<string, string | number> = {}): Record<string, unknown>[] {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const out: Record<string, unknown>[] = [];
  while (stmt.step()) out.push(stmt.getAsObject());
  stmt.free();
  return out;
}

/** Warunki WHERE z filtra – zawsze przez parametry, nigdy przez sklejanie tekstu. */
function where(f: ReplayFilter, withMap = true): { sql: string; params: Record<string, string | number> } {
  const parts: string[] = [];
  const params: Record<string, string | number> = {};
  const q = f.search?.trim().toLowerCase();
  if (q) {
    // każde słowo musi wystąpić gdziekolwiek (tytuł, artysta, poziom, mapper)
    q.split(/\s+/).slice(0, 6).forEach((word, i) => {
      parts.push(`instr(lower(coalesce(title,'') || ' ' || coalesce(artist,'') || ' ' || coalesce(version,'') || ' ' || coalesce(creator,'')), $w${i}) > 0`);
      params[`$w${i}`] = word;
    });
  }
  if (withMap && f.beatmapMd5) {
    parts.push('beatmap_md5 = $md5');
    params.$md5 = f.beatmapMd5;
  }
  if (f.source && f.source !== 'all') {
    parts.push('source = $source');
    params.$source = f.source;
  }
  if (f.sinceDays) {
    parts.push('played_at >= $since');
    params.$since = new Date(Date.now() - f.sinceDays * 86_400_000).toISOString();
  }
  if (f.mods) {
    parts.push('mods = $mods');
    params.$mods = f.mods === 'NM' ? '' : f.mods;
  }
  if (f.hidePartial) parts.push('partial = 0');
  return { sql: parts.length ? `WHERE ${parts.join(' AND ')}` : '', params };
}

const ORDER: Record<NonNullable<ReplayFilter['sort']>, string> = {
  newest: 'played_at DESC',
  oldest: 'played_at ASC',
  accuracy: 'accuracy DESC, played_at DESC',
  ur: 'ur ASC, played_at DESC'
};

export async function queryReplays(f: ReplayFilter): Promise<{ items: ReplaySummary[]; total: number }> {
  const db = await open();
  const w = where(f);
  const total = (rows(db, `SELECT COUNT(*) AS n FROM replays ${w.sql}`, w.params)[0]?.n as number) ?? 0;
  const order = ORDER[f.sort ?? 'newest'] ?? ORDER.newest;
  const items = rows(db, `SELECT ${SUMMARY_COLUMNS} FROM replays ${w.sql} ORDER BY ${order} LIMIT $limit`, {
    ...w.params,
    $limit: Math.max(1, Math.min(f.limit ?? 500, 5000))
  }).map(toSummary);
  return { items, total };
}

export async function listMaps(f: ReplayFilter): Promise<MapGroup[]> {
  const db = await open();
  const w = where(f, false);
  return rows(
    db,
    `SELECT beatmap_md5, artist, title, version, COUNT(*) AS attempts, MAX(played_at) AS last_played,
            MAX(accuracy) AS best_acc, MIN(ur) AS best_ur
     FROM replays ${w.sql}
     GROUP BY beatmap_md5
     ORDER BY attempts DESC, last_played DESC
     LIMIT 1000`,
    w.params
  ).map((r) => ({
    beatmapMd5: r.beatmap_md5 as string,
    artist: (r.artist as string) ?? '',
    title: (r.title as string) ?? '',
    version: (r.version as string) ?? '',
    attempts: r.attempts as number,
    lastPlayed: r.last_played as string,
    bestAccuracy: r.best_acc as number,
    bestUr: r.best_ur as number
  }));
}

export async function modCombos(): Promise<string[]> {
  const db = await open();
  return rows(db, 'SELECT mods, COUNT(*) AS n FROM replays GROUP BY mods ORDER BY n DESC').map((r) => (r.mods as string) || 'NM');
}

async function getSummary(id: string): Promise<ReplaySummary | null> {
  const db = await open();
  const row = rows(db, `SELECT ${SUMMARY_COLUMNS} FROM replays WHERE id = $id`, { $id: id })[0];
  return row ? toSummary(row) : null;
}

export async function getReplay(id: string): Promise<ReplayResult> {
  const db = await open();
  const row = rows(db, 'SELECT * FROM replays WHERE id = $id', { $id: id })[0];
  if (!row) return { ok: false, error: 'not-found' };
  return {
    ok: true,
    id,
    replayFile: row.file as string,
    mapFile: row.map_file as string,
    beatmapMd5: row.beatmap_md5 as string,
    map: {
      artist: row.artist as string,
      title: row.title as string,
      version: row.version as string,
      creator: row.creator as string,
      endMs: row.map_end_ms as number
    },
    analysis: JSON.parse(gunzipSync(row.analysis as Uint8Array).toString('utf8')) as ReplayAnalysis
  };
}

/** Ta sama gra niezależnie od pliku: mapa + chwila zagrania + wynik. */
export async function findPlay(beatmapMd5: string, playedAt: string, score: number): Promise<string | null> {
  const db = await open();
  const row = rows(db, 'SELECT id FROM replays WHERE beatmap_md5 = $md5 AND played_at = $at AND score = $score LIMIT 1', {
    $md5: beatmapMd5,
    $at: playedAt,
    $score: score
  })[0];
  return row ? (row.id as string) : null;
}

export async function hasReplay(id: string): Promise<boolean> {
  return (await getSummary(id)) !== null;
}

export async function knownFiles(): Promise<Set<string>> {
  const db = await open();
  return new Set(rows(db, 'SELECT file FROM replays').map((r) => (r.file as string).toLowerCase()));
}

export async function deleteReplay(id: string): Promise<void> {
  const db = await open();
  db.run('DELETE FROM replays WHERE id = $id', { $id: id });
  scheduleSave(db);
}

/** Wpisy bez policzonego BPM streamów (starsze wersje programu). */
export async function missingStreamBpm(limit = 200): Promise<{ id: string; mapFile: string }[]> {
  const db = await open();
  return rows(db, 'SELECT id, map_file FROM replays WHERE stream_bpm IS NULL LIMIT $limit', { $limit: limit }).map((r) => ({
    id: r.id as string,
    mapFile: r.map_file as string
  }));
}

export async function setStreamBpm(ids: string[], bpm: number): Promise<void> {
  const db = await open();
  for (const id of ids) db.run('UPDATE replays SET stream_bpm = $bpm WHERE id = $id', { $bpm: bpm, $id: id });
  scheduleSave(db);
}

// ---------- ćwiczenia ----------

export async function saveDrill(r: Omit<DrillRecord, 'id' | 'createdAt'>): Promise<DrillRecord> {
  const db = await open();
  const rec: DrillRecord = { ...r, id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`, createdAt: new Date().toISOString() };
  db.run(
    `INSERT INTO drills (id, created_at, kind, name, label, bpm, duration_ms, notes, accuracy, misses, extra_taps,
       wrong_finger, ur, mean, k1_mean, k2_mean, k1_ur, k2_ur, entry_mean, tap_spread, aim_distance, aim_overshoot, hit_rate)
     VALUES ($id, $at, $kind, $name, $label, $bpm, $dur, $notes, $acc, $miss, $extra, $wrong, $ur, $mean,
       $k1, $k2, $k1ur, $k2ur, $entry, $spread, $aimd, $aimo, $hit)`,
    {
      $id: rec.id,
      $at: rec.createdAt,
      $kind: rec.kind,
      $name: rec.name,
      $label: rec.label,
      $bpm: rec.bpm,
      $dur: rec.durationMs,
      $notes: rec.notes,
      $acc: rec.accuracy,
      $miss: rec.misses,
      $extra: rec.extraTaps,
      $wrong: rec.wrongFinger,
      $ur: rec.ur,
      $mean: rec.mean,
      $k1: rec.k1Mean,
      $k2: rec.k2Mean,
      $k1ur: rec.k1Ur,
      $k2ur: rec.k2Ur,
      $entry: rec.entryMean,
      $spread: rec.tapSpread,
      $aimd: rec.aimDistance ?? null,
      $aimo: rec.aimOvershoot ?? null,
      $hit: rec.hitRate ?? null
    }
  );
  scheduleSave(db);
  return rec;
}

export async function listDrills(kind: string | null, name: string | null, limit: number, sinceIso?: string): Promise<DrillRecord[]> {
  const db = await open();
  const params: Record<string, string | number> = { $limit: Math.max(1, Math.min(limit, 5000)) };
  const where: string[] = [];
  if (kind) {
    where.push('kind = $kind');
    params.$kind = kind;
  }
  if (name) {
    where.push('name = $name');
    params.$name = name;
  }
  if (sinceIso) {
    where.push('created_at >= $since');
    params.$since = sinceIso;
  }
  return rows(db, `SELECT * FROM drills ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY created_at DESC LIMIT $limit`, params).map(
    (r) => ({
      id: r.id as string,
      createdAt: r.created_at as string,
      kind: r.kind as DrillRecord['kind'],
      name: r.name as string,
      label: r.label as string,
      bpm: r.bpm as number,
      durationMs: r.duration_ms as number,
      notes: r.notes as number,
      accuracy: r.accuracy as number,
      misses: r.misses as number,
      extraTaps: r.extra_taps as number,
      wrongFinger: r.wrong_finger as number,
      ur: r.ur as number,
      mean: r.mean as number,
      k1Mean: r.k1_mean as number,
      k2Mean: r.k2_mean as number,
      k1Ur: r.k1_ur as number,
      k2Ur: r.k2_ur as number,
      entryMean: r.entry_mean as number,
      tapSpread: r.tap_spread as number,
      aimDistance: (r.aim_distance as number | null) ?? null,
      aimOvershoot: (r.aim_overshoot as number | null) ?? null,
      hitRate: (r.hit_rate as number | null) ?? null
    })
  );
}

export async function countReplays(): Promise<number> {
  const db = await open();
  return (db.exec('SELECT COUNT(*) FROM replays')[0]?.values[0]?.[0] as number) ?? 0;
}

// ---------- dostęp dla innych modułów (Biblioteka map) ----------

export type Params = Record<string, string | number | null>;

/** Zapytanie SELECT na wspólnej bazie. */
export async function select(sql: string, params: Params = {}): Promise<Record<string, unknown>[]> {
  const db = await open();
  const stmt = db.prepare(sql);
  stmt.bind(params as Record<string, string | number>);
  const out: Record<string, unknown>[] = [];
  while (stmt.step()) out.push(stmt.getAsObject());
  stmt.free();
  return out;
}

/** Kilka zapisów naraz w jednej transakcji; plik bazy zapisze się chwilę później. */
export async function writeMany(sql: string, list: Params[]): Promise<void> {
  if (!list.length) return;
  const db = await open();
  const stmt = db.prepare(sql);
  db.run('BEGIN');
  try {
    for (const p of list) stmt.run(p as Record<string, string | number>);
    db.run('COMMIT');
  } catch (e) {
    db.run('ROLLBACK');
    throw e;
  } finally {
    stmt.free();
  }
  scheduleSave(db);
}
