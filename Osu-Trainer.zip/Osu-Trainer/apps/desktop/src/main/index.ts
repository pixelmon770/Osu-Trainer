// Proces główny Electrona: okno programu, pliki, historia replayów i obserwowanie folderów.

import { readdir, readFile, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { electronApp, is, optimizer } from '@electron-toolkit/utils';
import { analyzeMapText } from '@osu-trainer/analyzer';
import { app, BrowserWindow, clipboard, dialog, ipcMain, Menu, Notification, shell, type OpenDialogOptions } from 'electron';
import {
  IPC,
  type AnalyzeResult,
  type AiExportOptions,
  type DialogLabels,
  type DrillRecord,
  type ImportProgress,
  type LibraryQuery,
  type ReplayFilter,
  type StatsQuery,
  type ReplayResult,
  type Settings,
  type SettingsStatus
} from '../shared/api.ts';
import * as history from './history.ts';
import { defaultSongsFolder, loadOsuDb } from './mapIndex.ts';
import { analyzeReplayFile } from './replayService.ts';
import { getSettings, songsFolder, updateSettings, watchedFolders } from './settings.ts';
import { text } from './texts.ts';
import { indexLazerStore, indexStoreFile, lazerIndexStatus, recentLazerReplays, sniffFile } from './lazer.ts';
import { dashboard, listSessions } from './sessions.ts';
import { aiExport, installMcp, mcpInfo, uninstallMcp } from './ai.ts';
import { goalsProgress } from './goals.ts';
import { loadPlayback } from './playback.ts';
import { backfillStreamBpm, computeStats } from './stats.ts';
import {
  indexLibrary,
  libraryMapPath,
  libraryStatus,
  mapLadder,
  playerProfile,
  queryLibrary
} from './library.ts';
import { ReplayWatcher } from './watcher.ts';

// Jeden stały folder danych – taki sam w trybie dev i w wersji zainstalowanej.
app.setPath('userData', join(app.getPath('appData'), 'osu-trainer'));

let mainWindow: BrowserWindow | null = null;

function createWindow(): void {
  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    show: false,
    backgroundColor: '#0f1012',
    title: 'osu! Trener',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true
    }
  });
  mainWindow = win;
  win.on('closed', () => {
    if (mainWindow === win) mainWindow = null;
  });
  win.on('ready-to-show', () => win.show());

  // Linki zewnętrzne otwieramy w przeglądarce, nie w oknie programu.
  win.webContents.setWindowOpenHandler(({ url }) => {
    void shell.openExternal(url);
    return { action: 'deny' };
  });

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    void win.loadURL(process.env['ELECTRON_RENDERER_URL']);
  } else {
    void win.loadFile(join(__dirname, '../renderer/index.html'));
  }
}

function send(channel: string, payload: unknown): void {
  mainWindow?.webContents.send(channel, payload);
}

async function pickFile(sender: Electron.WebContents, options: OpenDialogOptions): Promise<string | null> {
  const win = BrowserWindow.fromWebContents(sender);
  const picked = win ? await dialog.showOpenDialog(win, options) : await dialog.showOpenDialog(options);
  return picked.canceled ? null : (picked.filePaths[0] ?? null);
}

// ---------- mapy ----------

async function analyzeMapFile(file: string): Promise<AnalyzeResult> {
  try {
    return { ok: true, file, analysis: analyzeMapText(await readFile(file, 'utf8')) };
  } catch (e) {
    return { ok: false, file, error: (e as Error).message };
  }
}

ipcMain.handle(IPC.pickAndAnalyzeMap, async (event, labels: DialogLabels) => {
  const file = await pickFile(event.sender, {
    title: labels?.pickMap,
    defaultPath: defaultSongsFolder(),
    properties: ['openFile'],
    filters: [{ name: 'osu! beatmap', extensions: ['osu'] }]
  });
  return file ? analyzeMapFile(file) : null;
});

ipcMain.handle(IPC.analyzeMapFile, async (_event, file: unknown) => {
  if (typeof file !== 'string' || !file.toLowerCase().endsWith('.osu')) {
    return { ok: false, error: 'not-osu-file' } satisfies AnalyzeResult;
  }
  return analyzeMapFile(file);
});

// ---------- replaye otwierane ręcznie ----------

async function analyzeInteractive(sender: Electron.WebContents, file: string, mapHint: string | null, labels: DialogLabels) {
  const { result, summary } = await analyzeReplayFile(file, {
    mapHint,
    askForMap: () =>
      pickFile(sender, {
        title: labels?.pickMapForReplay,
        defaultPath: defaultSongsFolder(),
        properties: ['openFile'],
        filters: [{ name: 'osu! beatmap', extensions: ['osu'] }]
      })
  });
  if (summary) send(IPC.replayAdded, summary);
  return result;
}

ipcMain.handle(IPC.pickAndAnalyzeReplay, async (event, labels: DialogLabels) => {
  const s = getSettings();
  const file = await pickFile(event.sender, {
    title: labels?.pickReplay,
    defaultPath: s.osuFolder ? join(s.osuFolder, 'Replays') : undefined,
    properties: ['openFile'],
    filters: [{ name: 'osu! replay', extensions: ['osr'] }]
  });
  return file ? analyzeInteractive(event.sender, file, null, labels) : null;
});

ipcMain.handle(IPC.analyzeReplayFile, async (event, file: unknown, mapHint: unknown, labels: DialogLabels) => {
  if (typeof file !== 'string' || !file.toLowerCase().endsWith('.osr')) {
    return { ok: false, error: 'not-osr-file' } satisfies ReplayResult;
  }
  return analyzeInteractive(event.sender, file, typeof mapHint === 'string' ? mapHint : null, labels);
});

// ---------- historia ----------

ipcMain.handle(IPC.queryReplays, (_e, filter: ReplayFilter) => history.queryReplays(filter ?? {}));
ipcMain.handle(IPC.listMaps, (_e, filter: ReplayFilter) => history.listMaps(filter ?? {}));
ipcMain.handle(IPC.modCombos, () => history.modCombos());
ipcMain.handle(IPC.stats, (_e, q: StatsQuery) => computeStats(q ?? { sinceDays: 30 }));
ipcMain.handle(IPC.dashboard, () => dashboard());
ipcMain.handle(IPC.goalsProgress, () => goalsProgress());
ipcMain.handle(IPC.aiExport, (_e, o: AiExportOptions) =>
  aiExport({ days: Number(o?.days) || 30, replays: Math.min(100, Number(o?.replays) || 15), details: Math.min(10, Number(o?.details) || 0) })
);
ipcMain.handle(IPC.mcpInfo, () => mcpInfo());
ipcMain.handle(IPC.installMcp, () => installMcp());
ipcMain.handle(IPC.uninstallMcp, () => uninstallMcp());
ipcMain.handle(IPC.copyText, (_e, text: unknown) => {
  if (typeof text === 'string') clipboard.writeText(text);
});
ipcMain.handle(IPC.saveText, async (event, text: unknown, name: unknown) => {
  if (typeof text !== 'string') return null;
  const win = BrowserWindow.fromWebContents(event.sender);
  const options = {
    defaultPath: join(app.getPath('documents'), typeof name === 'string' ? name : 'osu-trener.md'),
    filters: [{ name: 'Markdown', extensions: ['md'] }]
  };
  const r = win ? await dialog.showSaveDialog(win, options) : await dialog.showSaveDialog(options);
  if (r.canceled || !r.filePath) return null;
  await writeFile(r.filePath, text, 'utf8');
  return r.filePath;
});
ipcMain.handle(IPC.playback, (_e, id: string) => loadPlayback(String(id)));
ipcMain.handle(IPC.sessions, (_e, sinceDays: number | null) => listSessions(typeof sinceDays === 'number' ? sinceDays : null));
ipcMain.handle(IPC.saveDrill, (_e, r: Omit<DrillRecord, 'id' | 'createdAt'>) => history.saveDrill(r));
ipcMain.handle(IPC.listDrills, (_e, kind: string, name: string | null, limit: number) =>
  history.listDrills(typeof kind === 'string' ? kind : null, typeof name === 'string' ? name : null, Number(limit) || 200)
);
ipcMain.handle(IPC.pickMapText, async (event, labels: DialogLabels) => {
  const file = await pickFile(event.sender, {
    title: labels?.pickMap,
    defaultPath: defaultSongsFolder(),
    properties: ['openFile'],
    filters: [{ name: 'osu! beatmap', extensions: ['osu'] }]
  });
  return file ? { file, text: await readFile(file, 'utf8') } : null;
});
ipcMain.handle(IPC.getReplay, (_e, id: string) => history.getReplay(String(id)));
ipcMain.handle(IPC.deleteReplay, (_e, id: string) => history.deleteReplay(String(id)));

let importRunning = false;
ipcMain.handle(IPC.importReplays, async (_e, days: number, limit: number): Promise<ImportProgress> => {
  const progress: ImportProgress = { done: 0, total: 0, imported: 0, skipped: 0, failed: 0, finished: false, folders: [] };
  if (importRunning) return { ...progress, finished: true };
  importRunning = true;
  try {
    const since = Date.now() - Math.max(1, Number(days) || 30) * 86_400_000;
    const known = await history.knownFiles();
    const candidates: { file: string; mtime: number }[] = [];
    const settings = getSettings();
    for (const folder of watchedFolders().filter((f) => f.enabled && f.exists)) {
      let found: { file: string; mtime: number }[] = [];
      if (folder.kind === 'lazer' && settings.lazerFolder) {
        found = await recentLazerReplays(settings.lazerFolder, since);
      } else {
        for (const name of await readdir(folder.path).catch(() => [] as string[])) {
          if (!name.toLowerCase().endsWith('.osr')) continue;
          const file = join(folder.path, name);
          const st = await stat(file).catch(() => null);
          if (st && st.mtimeMs >= since) found.push({ file, mtime: st.mtimeMs });
        }
      }
      progress.folders.push({ path: folder.path, kind: folder.kind, found: found.length });
      candidates.push(...found.filter((c) => !known.has(c.file.toLowerCase())));
    }
    candidates.sort((a, b) => b.mtime - a.mtime);
    const todo = candidates.slice(0, Math.max(1, Math.min(Number(limit) || 100, 1000)));
    progress.total = todo.length;
    send(IPC.importProgress, progress);
    for (const c of todo) {
      const { result, summary, duplicate } = await analyzeReplayFile(c.file, { skipIfKnown: true });
      if (summary) progress.imported++;
      else if (duplicate || (result && !result.ok && result.error === 'map-not-found')) progress.skipped++;
      else progress.failed++;
      progress.done++;
      send(IPC.importProgress, progress);
    }
  } finally {
    importRunning = false;
  }
  progress.finished = true;
  send(IPC.importProgress, progress);
  return progress;
});

// ---------- automatyczne replaye ----------

const watcher = new ReplayWatcher(async (file, lazer) => {
  const s = getSettings();
  if (lazer) {
    // magazyn lazera: nowa mapa trafia do indeksu, replay idzie do analizy, reszta (audio, tła) jest pomijana
    const kind = await sniffFile(file);
    if (kind === 'osu') return indexStoreFile(file, kind);
    if (kind !== 'osr') return;
  }
  if (!s.autoAnalyze) return;
  // tylko świeże gry: stare replaye zapisane ponownie (np. przez lazera) nie są nową grą
  const { result, summary, old } = await analyzeReplayFile(file, { skipIfKnown: true, maxAgeHours: 12 });
  if (old) return;
  if (summary) {
    send(IPC.replayAdded, summary);
    if (s.notifications && !mainWindow?.isFocused() && Notification.isSupported()) {
      new Notification({
        title: text(s.language, 'newReplay'),
        body: text(s.language, 'replayBody', {
          map: `${summary.title} [${summary.version}]`,
          acc: summary.accuracy.toFixed(2),
          ur: summary.ur.toFixed(0)
        })
      }).show();
    }
  } else if (result && !result.ok) {
    send(IPC.replayFailed, { file, error: result.error });
  }
});

function restartWatcher(): void {
  watcher.start(
    watchedFolders()
      .filter((f) => f.enabled && f.exists)
      .map((f) => ({ path: f.path, lazer: f.kind === 'lazer' }))
  );
}

// ---------- ustawienia ----------

async function status(): Promise<SettingsStatus> {
  const settings = getSettings();
  const db = await loadOsuDb();
  return {
    settings,
    osuFolderFound: !!settings.osuFolder,
    songsFolder: songsFolder(settings.osuFolder),
    osuDb: db ? { maps: db.maps, player: db.player, error: db.error } : null,
    lazer: (() => {
      const l = lazerIndexStatus();
      return { found: !!settings.lazerFolder, indexedMaps: l.maps, indexing: l.running };
    })(),
    folders: watchedFolders(settings),
    canAutostart: app.isPackaged,
    historyCount: await history.countReplays()
  };
}

ipcMain.handle(IPC.getSettings, () => status());

ipcMain.handle(IPC.updateSettings, async (_e, patch: Partial<Settings>) => {
  const allowed: (keyof Settings)[] = [
    'osuFolder',
    'watchDataR',
    'watchReplays',
    'lazerFolder',
    'watchLazer',
    'extraFolders',
    'autoAnalyze',
    'notifications',
    'openAtLogin',
    'language',
    'keyK1',
    'keyK2',
    'audioOffsetMs',
    'volume',
    'drillOd',
    'roadmap',
    'goals',
    'todos'
  ];
  const clean = Object.fromEntries(Object.entries(patch ?? {}).filter(([k]) => allowed.includes(k as keyof Settings)));
  const s = await updateSettings(clean);
  if ('openAtLogin' in clean && app.isPackaged) app.setLoginItemSettings({ openAtLogin: s.openAtLogin });
  if (['osuFolder', 'watchDataR', 'watchReplays', 'lazerFolder', 'watchLazer', 'extraFolders'].some((k) => k in clean)) restartWatcher();
  if ('lazerFolder' in clean && s.lazerFolder) void indexLazerStore(s.lazerFolder).then(() => indexLibrary());
  if ('osuFolder' in clean) void indexLibrary();
  return status();
});

// ---------- Biblioteka map ----------

ipcMain.handle(IPC.queryLibrary, (_e, q: LibraryQuery) => queryLibrary(q ?? {}));
ipcMain.handle(IPC.libraryStatus, () => libraryStatus());
ipcMain.handle(IPC.reindexLibrary, async (_e, force: unknown) => {
  await loadOsuDb();
  void indexLibrary(force === true);
});
ipcMain.handle(IPC.playerProfile, () => playerProfile());
ipcMain.handle(IPC.mapLadder, (_e, md5: unknown, steps: unknown) =>
  typeof md5 === 'string' ? mapLadder(md5, typeof steps === 'number' ? steps : 4) : { target: null, basis: 'general', steps: [] }
);
ipcMain.handle(IPC.libraryMapText, async (_e, md5: unknown) => {
  if (typeof md5 !== 'string') return null;
  const file = await libraryMapPath(md5); // tylko pliki z biblioteki, nie dowolne ścieżki
  return file ? { file, text: await readFile(file, 'utf8') } : null;
});
ipcMain.handle(IPC.analyzeLibraryMap, async (_e, md5: unknown) => {
  const file = typeof md5 === 'string' ? await libraryMapPath(md5) : null;
  return file ? analyzeMapFile(file) : ({ ok: false, error: 'not-found' } satisfies AnalyzeResult);
});

ipcMain.handle(IPC.pickFolder, async (event, labels: DialogLabels) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const options: OpenDialogOptions = { title: labels?.pickFolder, properties: ['openDirectory'] };
  const picked = win ? await dialog.showOpenDialog(win, options) : await dialog.showOpenDialog(options);
  return picked.canceled ? null : (picked.filePaths[0] ?? null);
});

ipcMain.handle(IPC.openPath, async (_e, path: unknown) => {
  if (typeof path === 'string') await shell.openPath(path);
});

ipcMain.handle(IPC.version, () => app.getVersion());

// ---------- start ----------

app.whenReady().then(() => {
  electronApp.setAppUserModelId('io.github.pixelmon770.osutrainer');
  // Bez paska File/Edit/View – program ma własne menu z boku.
  Menu.setApplicationMenu(null);
  // F12 otwiera narzędzia deweloperskie w trybie dev, Ctrl+R jest wyłączone w wersji gotowej.
  app.on('browser-window-created', (_, window) => optimizer.watchWindowShortcuts(window));
  createWindow();
  restartWatcher();
  void loadOsuDb(); // wczytaj listę map od razu, żeby pierwszy replay nie czekał
  const lazerFolder = getSettings().lazerFolder;
  void backfillStreamBpm(); // w tle: BPM streamów dla wpisów ze starszych wersji
  // w tle: MD5 map z magazynu lazera, potem Biblioteka map (analizuje tylko nowe mapy)
  void (lazerFolder ? indexLazerStore(lazerFolder) : Promise.resolve()).then(() => loadOsuDb()).then(() => indexLibrary());
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

let quitting = false;
app.on('before-quit', (e) => {
  watcher.stop();
  // poczekaj na zapis historii, zanim program się zamknie
  if (!quitting && history.hasPendingSave()) {
    e.preventDefault();
    quitting = true;
    void history.flushNow().finally(() => app.quit());
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
